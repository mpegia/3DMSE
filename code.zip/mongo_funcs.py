from pymongo import MongoClient
import pymongo
import operator
import datetime
from bson.binary import Binary
import pickle
import os
from dotenv import load_dotenv


def load_mongo_credentials(env_path):
    load_dotenv(env_path)
    credentials = {
                    "username": os.getenv("MONGO_USERNAME"),
                    "password": os.getenv("MONGO_PASSWORD"),
                    "host": os.getenv("MONGO_HOST"),
                    "port": int(os.getenv("MONGO_PORT")),
                    "databaseName": os.getenv("MONGO_DB"),
                    "authMechanism": os.getenv("MONGO_AUTH_MECHANISM")
                }
    return credentials


def connect_mongo():
    mongo_info = load_mongo_credentials('.env')
    client = MongoClient(
                            mongo_info['host'],
                            mongo_info['port'],
                            username = mongo_info['username'],
                            password = mongo_info['password'],
                            authSource = mongo_info['databaseName'],
                            authMechanism = mongo_info['authMechanism']
                        )
    
    db = client[mongo_info['databaseName']]

    return client, db 


def disconnect_mongo(client):
    client.close()


def create_mongo_record_ModelNet40(response, feature):
    record = {}

    # Videoshot info
    record['file_name'] = response['file_name']
    record['no_frame'] = response['no_frame']
    record['category_name'] = response['category_name']
    record['category_id'] = response['category_id']
    
    record['metadata'] = {}
    record['metadata']['mesh_feature'] = feature.tolist()

    return record['file_name_obj'], record


def create_mongo_record_BuilingNet(response, feature):
    record = {}

    # Videoshot info
    record['file_name'] = response['file_name']
    record['no_frame'] = response['no_frame']
    record['category_name'] = response['category_name']
    record['category_id'] = response['category_id']
    record['land_use_category'] = response['land_use_category']
    record['building_category_name'] = response['building_category_name']
    
    record['metadata'] = {}
    record['metadata']['mesh_feature'] = feature.tolist()

    return record['file_name'], record


def insert_record_if_not_exists(product_name, record, collection):
    # product_inserted = False

    # doc = collection.find_one({'file_name_obj': product_name})

    # if doc == None:
    collection.insert_one(record)
    product_inserted = True

    return product_inserted


def get_products_and_metadata(products_lst, collection):
    products_metadata_lst = []

    result = collection.find({'$and': [{'category_names': {'$exists': 1}}, {'category_names': {'$in': products_lst}}]})

    for doc in result:
        #print(doc)
        prod_meta = {}
        prod_meta['shot_name'] = doc['shot_name'].strip()
        products_metadata_lst.append(prod_meta)

    return products_metadata_lst 


