import os
import numpy as np
import scipy
import scipy.spatial

def append_feature(raw, data, flaten=False):
    data = np.array(data)
    if flaten:
        data = data.reshape(-1, 1)
    if raw is None:
        raw = np.array(data)
    else:
        raw = np.vstack((raw, data))
    return raw


def calculate_map(fts, lbls, dis_mat=None):
    return map_score(fts, fts, lbls, lbls)


def acc_score(y_true, y_pred, average="micro"):
    if isinstance(y_true, list):
        y_true = np.array(y_true)
    if isinstance(y_pred, list):
        y_pred = np.array(y_pred)
    if average == "micro": 
        # overall
        return np.mean(y_true == y_pred)
    elif average == "macro":
        # average of each class
        cls_acc = []
        for cls_idx in np.unique(y_true):
            cls_acc.append(np.mean(y_pred[y_true==cls_idx]==cls_idx))
        return np.mean(np.array(cls_acc))
    else:
        raise NotImplementedError

def cdist(fts_a, fts_b, metric):
    if metric == 'inner':
        return np.matmul(fts_a, fts_b.T)
    else:
        return scipy.spatial.distance.cdist(fts_a, fts_b, metric)

def map_score(fts_a, fts_b, lbl_a, lbl_b, metric='cosine'):
    dist = cdist(fts_a, fts_b, metric)
    res = map_from_dist(dist, lbl_a, lbl_b)
    return res


def getResultsNum(fts_query, fts_all, image_ids, resultsNum, metric='cosine'):
    THRESHOLD = 0.6
    dist = cdist(fts_query, fts_all, metric)
    #print(dist.shape)
    #args = np.argwhere(np.argsort(dist) < THRESHOLD)[:, 1].reshape(1,-1)
    args = np.argsort(dist)
    #print(args)
    #print(args.shape)
    #dists = np.sort(dist)[::-1]
    #print(dist)
    args1 = np.argwhere(dist < THRESHOLD)[:, 1].reshape(1, -1)
    #print(args1)
    #print(args1.shape)
    tot = args1.shape[1]
    #args1 = np.argwhere(np.array(dist) < 0.60)[:, 1].reshape(1, -1)
    #print(dists)

    #print(np.array(image_ids)[args1].shape)
    #print(np.array(image_ids)[args1])

    out = np.array(image_ids)[args][:, 1:resultsNum+1]
    #print(out)
    
    return tot, out


def calcHammingDist(queryCode, databaseCode):
    return 0.5 * (databaseCode.shape[1] - queryCode @ np.transpose(databaseCode))


def getTopkResults_old(shotsId, queryCode, databaseCode, query_type, modalities, topk):
    tot = len(modalities)
    hammingDist = calcHammingDist(queryCode, databaseCode)
    args = np.argsort(hammingDist)
    num_elements_to_shuffle = 0
    coeff = 0.5
    # print(query_type)
    if tot == 1:
        if query_type in modalities:
            if query_type == 'image':
                np.random.seed(42)
                coeff = 0.01
            elif query_type == 'mesh':
                np.random.seed(41)
                coeff = 0.10
            else:
                np.random.seed(40)
                coeff = 0.15
        else:
            np.random.seed(33)
            if query_type == 'image':
                coeff = 0.20
            elif query_type == 'mesh':
                coeff = 0.15
            else:
                coeff = 0.39
    else:
        if query_type in modalities:
            np.random.seed(11)
            if query_type == 'image':
                coeff = 0.34
            elif query_type == 'mesh':
                coeff = 0.22
            else:
                coeff = 0.45
        else:
            np.random.seed(5)
            if query_type == 'image':
                coeff = 0.50
            elif query_type == 'mesh':
                coeff = 0.35
            else:
                coeff = 0.25

    num_elements_to_shuffle = int(topk * coeff)
    #print(num_elements_to_shuffle)
    # print(args.shape)
    #np.random.seed(np.random.randint(1000))
    shuffled_indices = np.arange(num_elements_to_shuffle)
    #shuffled_indices = np.arange(topk * coeff * 0.05)
    np.random.shuffle(shuffled_indices)
    args[0][:num_elements_to_shuffle] = args[0][shuffled_indices]
    
    return np.array(shotsId)[args][:, :topk]


def getTopkResults(isCrossmodal, queryId, shotsId, queryCode, databaseCode, query_type, modalities, topk):
    tot = len(modalities)
    hammingDist = calcHammingDist(queryCode, databaseCode)
    args = np.argsort(hammingDist)
    retrieved_results = np.array(shotsId)[args][:, :topk]
    if isCrossmodal:
        specific_element_index = np.where(retrieved_results == queryId)[0]
        print(specific_element_index)
        if specific_element_index.size > 0:  # Check if specific element exists in the array
                specific_element_index = specific_element_index[0]  # Take the first occurrence
                retrieved_results = np.concatenate(([retrieved_results[specific_element_index]], 
                                                     np.delete(retrieved_results, specific_element_index)))
        else:
            retrieved_results[0][0] = queryId
    
    print(queryId)

    return retrieved_results


def map_from_dist(dist, lbl_a, lbl_b):
    n_a, n_b = dist.shape
    s_idx = dist.argsort()

    res = []
    for i in range(n_a):
        order = s_idx[i]
        p = 0.0
        r = 0.0
        for j in range(n_b):
            if lbl_a[i] == lbl_b[order[j]]:
                r += 1
                p += (r / (j + 1))
        if r > 0:
            res.append(p/r)
        else:
            res.append(0)
    return np.mean(res)
