from __future__ import print_function
from json import dumps
from bottle import route, run, template, request, response, post, get, BaseRequest, BaseResponse
import searchByQuery as sq

@route('/3DMeshRetrievalServiceXRECO')
def index():
    queryId = request.query.get("image_id")
    collection = request.query.get("collection")
    query_type = request.query.get("type")
    retrieved_types = request.query.get("retrieved_types").split(",")
    resultsNum = int(request.query.get("limit"))

    print(queryId, collection, query_type, retrieved_types, resultsNum)

    retrieved_results = sq.searchByQuery(queryId, collection, query_type, retrieved_types, resultsNum)
    output = retrieved_results.tolist()

    response.content_type = 'application/json'
    response.headers['Access-Control-Allow-Origin'] = '*'
    return dumps(output)

#run(host='160.40.51.17', port=9008)
run(host='160.40.53.88', port=9008)
