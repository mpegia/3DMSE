# TITLE 3D MESH RETRIEVAL SERVICE

#!/bin/bash
# Title: 3D Retrieval Service
SERVICE_URL=""

# Change directory
cd "/home/MyProjects/GUI"

# Activate virtual environment
# Define the path to your virtual environment's 'activate' script
VENV_PATH="env/bin/activate"

# Check if the 'activate' script exists
if [ -f "$VENV_PATH" ]; then
    # Activate the virtual environment
    source "$VENV_PATH"
    echo "Virtual environment activated."
else
    echo "Error: Virtual environment 'activate' script not found at $VENV_PATH."
fi


# Run Python script
python3 3DMeshRetrievalServiceFor3DMesh.py

# Pause (wait for user input)
read -p "Press Enter to continue..."
