import numpy as np
from utils import getTopkResults
from mongo_funcs import connect_mongo, disconnect_mongo


def getShotHashCodeBasedOnId(collection, queryId, modalities):
    result = collection.find({'file_name': queryId})
    hashCode = None
    if not isinstance(modalities, list):
        modalities = [modalities]
    num_modalities = len(modalities)
    print(num_modalities)

    if num_modalities > 0:
        if num_modalities == 1:
            for doc in result:
                hashCode = np.array(doc['metadata'][modalities[0] + '_hash_code']).astype(int)
        elif num_modalities == 2:
            for doc in result:
                hashCode1 = np.array(doc['metadata'][modalities[0] + '_hash_code']).astype(int)
                hashCode2 = np.array(doc['metadata'][modalities[1] + '_hash_code']).astype(int)
                hashCode = np.bitwise_xor(hashCode1, hashCode2)
        elif num_modalities == 3:
            for doc in result:
                hashCode1 = np.array(doc['metadata'][modalities[0] + '_hash_code']).astype(int)
                hashCode2 = np.array(doc['metadata'][modalities[1] + '_hash_code']).astype(int)
                hashCode3 = np.array(doc['metadata'][modalities[2] + '_hash_code']).astype(int)
                hashCode = np.bitwise_and(np.bitwise_and(hashCode1, hashCode2), np.bitwise_and(hashCode1, hashCode3), np.bitwise_and(hashCode2, hashCode3))
    else:
        raise ValueError('Unsupported number of modality')

    return hashCode.reshape(1, -1)


def getAllShotsHashCodeExcludingQueryId(collection, modality, queryId):
    # Get all documents except query
    results = collection.find({'file_name': {'$ne': queryId}})
    hashCodes = []
    shotsId = []
    numModalities = len(modality)
    print(numModalities)

    if numModalities > 0:
        if numModalities == 1:
            for doc in results:
                shotId = doc['file_name']
                hashCode = np.array(doc['metadata'][modality[0] + '_hash_code']).astype(int).reshape(1, -1)
                hashCodes.append(hashCode)
                shotsId.append(shotId)
        elif numModalities == 2:
            for doc in results:
                shotId = doc['file_name']
                hashCode1 = np.array(doc['metadata'][modality[0] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode2 = np.array(doc['metadata'][modality[1] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode = np.bitwise_and(hashCode1, hashCode2).reshape(1, -1)
                hashCodes.append(hashCode)
                shotsId.append(shotId)
        elif numModalities == 3:
            for doc in results:
                shotId = doc['file_name']
                hashCode1 = np.array(doc['metadata'][modality[0] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode2 = np.array(doc['metadata'][modality[1] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode3 = np.array(doc['metadata'][modality[2] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode =  np.bitwise_and(np.bitwise_or(hashCode1, hashCode2), np.bitwise_or(hashCode1, hashCode3), np.bitwise_or(hashCode2, hashCode3)).reshape(1, -1)
                hashCodes.append(hashCode)
                shotsId.append(shotId)
    else:
        raise ValueError('Unsupported number of modalities')

    print(len(hashCodes))
    return shotsId, np.vstack(hashCodes)


def getAllShotsHashCodeIncludingQueryId(collection, modality, queryId):
    # Get all documents except query
    results = collection.find({})
    hashCodes = []
    shotsId = []
    numModalities = len(modality)
    print(numModalities)

    if numModalities > 0:
        if numModalities == 1:
            for doc in results:
                shotId = doc['file_name']
                hashCode = np.array(doc['metadata'][modality[0] + '_hash_code']).astype(int).reshape(1, -1)
                hashCodes.append(hashCode)
                shotsId.append(shotId)
        elif numModalities == 2:
            for doc in results:
                shotId = doc['file_name']
                hashCode1 = np.array(doc['metadata'][modality[0] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode2 = np.array(doc['metadata'][modality[1] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode = np.bitwise_and(hashCode1, hashCode2).reshape(1, -1)
                hashCodes.append(hashCode)
                shotsId.append(shotId)
        elif numModalities == 3:
            for doc in results:
                shotId = doc['file_name']
                hashCode1 = np.array(doc['metadata'][modality[0] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode2 = np.array(doc['metadata'][modality[1] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode3 = np.array(doc['metadata'][modality[2] + '_hash_code']).astype(int).reshape(1, -1)
                hashCode =  np.bitwise_and(np.bitwise_or(hashCode1, hashCode2), np.bitwise_or(hashCode1, hashCode3), np.bitwise_or(hashCode2, hashCode3)).reshape(1, -1)
                hashCodes.append(hashCode)
                shotsId.append(shotId)
    else:
        raise ValueError('Unsupported number of modalities')

    print(len(hashCodes))
    return shotsId, np.vstack(hashCodes)


def searchByQuery(queryId, collection_name, query_type, retrieved_types, topk):
    # Connect to Mongo
    isUnimodal = False
    isCrossmodal = False
    if collection_name == 'BuildingNet_v0' or collection_name == 'ShapeNetCore':
        num_avail_modalities = 3

    client, database = connect_mongo()
    collection = database[collection_name]
    modalities = ['point_cloud' if type_name == 'PointCloud' else type_name.lower() for type_name in retrieved_types]
    num_modalities = len(modalities) # >1 -> multimodal, 1 uni-modal (same modality) or cross-modal (if diff modalities)
    query_type = 'point_cloud' if query_type == 'PointCloud' else query_type.lower()
    print(client)
    print(database)
    print(modalities)

    if num_modalities > 1:
        queryCode = getShotHashCodeBasedOnId(collection, queryId, query_type)
        shotsId, databaseCodes = getAllShotsHashCodeExcludingQueryId(collection, modalities, queryId)
    else:
        isUnimodal = query_type == modalities[0]
        queryCode = getShotHashCodeBasedOnId(collection, queryId, query_type)
        if isUnimodal:
            shotsId, databaseCodes = getAllShotsHashCodeExcludingQueryId(collection, modalities, queryId)
        else:
            isCrossmodal = True
            shotsId, databaseCodes = getAllShotsHashCodeIncludingQueryId(collection, modalities, queryId)

    # Query to Mongo. Find resultsNum relevant to query documents
    results = getTopkResults(isCrossmodal, queryId, shotsId, queryCode, databaseCodes, query_type, modalities, topk)
    print(results)
    # Diconnect Mongo
    disconnect_mongo(client)

    return results


def update_records(collection_name):
    field_to_update = 'point_hash_code'
    new_field_name = 'point_cloud_hash_code'

    # Find documents that contain the field to update
    client, database = connect_mongo()
    collection = database[collection_name]
    documents_to_update = collection.find({})
    # Iterate over the documents
    for document in documents_to_update:
        print(document)
        # Update the field name
        new_value = document['metadata'][field_to_update]
        del document['metadata'][field_to_update]
        document['metadata'][new_field_name] = new_value
        # Update the document in the collection
        collection.replace_one({"_id": document["_id"]}, document)


if __name__ == '__main__':
    #queryId = 'COMMERCIALhotel_building_mesh0555' #'xbox_0094'
    #collection = 'BuildingNet_v0'
    collection = 'ShapeNetCore'
    resultsNum = 200
    #update_records(collection)

    #results = searchByQuery(queryId, collection, 'Mesh', ['Image', 'Mesh'], resultsNum)
    #print(results)

